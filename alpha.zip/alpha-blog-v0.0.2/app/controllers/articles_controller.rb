# frozen_string_literal: true

# ArticlesController ..
class ArticlesController < ApplicationController
  before_action :set_article, only: %i[show edit update destroy]

  def show; end

  def index
    @articles = Article.all
  end

  def new
    @article = Article.new
  end

  def create
    @article = Article.new(article_params)

    if @article.save
      flash[:notice] = 'Article saved!'
      # long way redirect_to article_path(@article)
      redirect_to @article # simpler way
    else
      flash[:alert] = 'Failed to save article!'
      render 'new'
    end
  end

  def edit; end

  def update
    # @article.title = params[:article][:title]
    # @article.description = params[:article][:description]

    if @article.update(article_params)
      flash[:notice] = 'Article updated!'
      # long way redirect_to article_path(@article)
      redirect_to @article # simpler way
    else
      flash[:alert] = 'Failed to update article!'
      render 'edit'
    end
  end

  def destroy
    @article.destroy

    flash[:notice] = 'Article deleted!'
    redirect_to articles_path
  end

  private

  def set_article
    @article = Article.find(params[:id])
  end

  def article_params
    params.require(:article).permit(:title, :description)
  end
end
