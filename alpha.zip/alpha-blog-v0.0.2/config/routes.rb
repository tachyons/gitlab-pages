# frozen_string_literal: true

Rails.application.routes.draw do
  root 'pages#home'
  get 'home', to: 'pages#home'
  get 'about', to: 'pages#about'
  resources :articles # same as having resources :articles, only: %i[show index new create edit update destroy]
end
